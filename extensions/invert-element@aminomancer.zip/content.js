"use strict";

function onShown(el) {
    let props = {};
    let mode;
    if (el) {
        let { filter } = el.style;
        props.visible = true;
        if (filter) {
            let arr = filter.split(" ");
            let invert = arr.find((fn) => fn.startsWith("invert"));
            let val = parseFloat(/^invert\((?<num>[0-9\.\,]+)\)$/.exec(invert)?.groups?.num);
            props.title = val > 0 ? "Uninvert Element" : "Invert Element";
            mode = !(val > 0);
        } else {
            props.title = "Invert Element";
            mode = true;
        }
    } else props.visible = false;
    return { props, mode };
}

function onClick(el, mode) {
    let val, priority;
    let { filter } = el.style;
    if (filter) {
        let arr = filter.split(" ");
        let existed;
        arr = arr
            .map((fn) => {
                if (fn.startsWith("invert")) {
                    existed = true;
                    return mode ? "invert(1)" : false;
                }
                return fn;
            })
            .filter(Boolean);
        if (mode && !existed) arr.push("invert(1)");
        val = arr.join(" ").trim();
        priority = el.style.getPropertyPriority("filter");
    } else {
        if (mode) {
            val = "invert(1)";
            priority = "important";
        } else val = priority = "";
    }
    el.style.setProperty("filter", val, priority);
}

browser.runtime.onMessage.addListener((request) => {
    let el = browser.menus.getTargetElement(request.targetElementId);
    switch (request.event) {
        case "shown":
            return Promise.resolve(onShown(el));
        case "click":
            if (el) onClick(el, request.mode);
            break;
        default:
    }
});
