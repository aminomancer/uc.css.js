let mode;

browser.menus.create({
    id: "menuitem-invert",
    title: "Invert Element",
    contexts: ["audio", "editable", "frame", "image", "link", "page", "password", "video"],
    documentUrlPatterns: ["<all_urls>"],
});

browser.menus.onShown.addListener(async function (info, tab) {
    let { targetElementId, frameId } = info;
    browser.tabs
        .sendMessage(tab.id, { event: "shown", targetElementId }, { frameId })
        .then((response) => {
            mode = response.mode;
            browser.menus.update("menuitem-invert", response.props);
            browser.menus.refresh();
        });
});

browser.menus.onClicked.addListener(function (info, tab) {
    let { targetElementId, frameId } = info;
    browser.tabs.sendMessage(tab.id, { event: "click", targetElementId, mode }, { frameId });
});
